export class Item {

   itemid!:number;
   itemname!:string;
    price!:number;
}
