export class User {

    firstname!: string;
    lastname!:string;
    email!:string
    password!:string
    gender!:string
    city!:string
    phoneno!:number
}
